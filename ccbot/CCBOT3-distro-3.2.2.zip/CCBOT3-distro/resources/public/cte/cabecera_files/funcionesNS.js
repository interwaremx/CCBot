function getTextFromItem(item){
	return item.textContent;
}